<?php
if (isset($_POST['data']) and !empty($_POST['data'])) {
    // "code": 1203,
    // "message": "Incorrect OTP Code"


    // valid but have error for maintain
    // "code": 1001,
    //   "message": "General error"


    // valid but have error for clientid
    // "code": 1106,
    // "message": "Client not found"

}
